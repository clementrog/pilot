# Skills

Knowledge modules for domain-specific guidance.

Browse templates at https://skills.sh

Reference in TASK.json:
```json
{
  "context": {
    "skills": ["frontend-design", "api-patterns"]
  }
}
```
